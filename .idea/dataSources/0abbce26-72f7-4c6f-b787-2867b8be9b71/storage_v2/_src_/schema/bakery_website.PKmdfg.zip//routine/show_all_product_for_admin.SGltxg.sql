create
    definer = root@localhost procedure show_all_product_for_admin()
begin
	select product.product_id, product.product_name, product.amount, product.price, product.thumbnail, product.description, category.category_id, category.category_name
    from product
    inner join category on product.category_id = category.category_id;
end;

