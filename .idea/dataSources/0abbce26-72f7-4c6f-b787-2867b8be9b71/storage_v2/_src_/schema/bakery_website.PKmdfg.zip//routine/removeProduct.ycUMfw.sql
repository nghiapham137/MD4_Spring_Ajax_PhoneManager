create
    definer = root@localhost procedure removeProduct(IN id int)
begin
	delete from product
    where product_id = id;
end;

